# Job Search Agent Starter Kit

This folder is a working job search agent with the blanks left for you to fill in. Once it's filled in, you paste in a job description and get a role assessment, a tailored resume, and (if you want one) a cover letter.

## What's in here

```
job-search-agent-starter/
├── START-HERE.md                      <- you are here
├── generated-resumes/                 <- finished resumes land here
└── .claude/                           <- hidden folder (see note below)
    ├── agents/
    │   └── job-search-coach.md        <- the agent: your criteria and rules
    └── skills/
        └── resume-tailor/
            ├── SKILL.md               <- how resumes and cover letters get built
            ├── references/
            │   ├── professional-experience.md   <- YOUR career history (fill this in first)
            │   └── content-guide.md             <- bullet formulas and tone
            └── assets/
                ├── MASTER_RESUME_TEMPLATE.html
                └── COVER_LETTER_TEMPLATE.html
```

## The fastest way to fill it in

You don't have to edit anything by hand. Open this folder in Claude (the app or the terminal) and paste this:

```
Read START-HERE.md and everything in .claude/. Every [[double bracket]] is a blank for me to fill in. Interview me one question at a time to fill in all of them, starting with professional-experience.md. Ask me to paste my current resume first and use it to pre-fill what you can. Before saving anything, show me what you plan to write and wait for my OK. Do not invent anything I haven't told you.
```

## Rules the agent follows (keep these)

- It never invents accomplishments, metrics, titles, or dates. It only uses what's in `professional-experience.md`.
- It always starts from the master template and never forces page breaks.
- It waits for your approval before building a resume.

## About the hidden `.claude` folder

Folders that start with a dot are hidden on your computer.

- **Mac (Finder):** press `Cmd + Shift + .` to show or hide them.
- **Windows (File Explorer):** View menu, then Show, then Hidden items.

You don't need to see them if you let Claude do the editing.

## Keep it private

Your career history is personal. If you back this folder up to GitHub, make the repository **private**.
