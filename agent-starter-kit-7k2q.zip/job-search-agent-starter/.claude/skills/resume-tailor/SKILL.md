---
name: resume-tailor
description: Create tailored HTML resumes and cover letters from a job description. Use when the user pastes a job description and asks for a tailored resume or cover letter, or says things like "tailor my resume for this role" or "write a cover letter for this".
---

# Resume Tailor

Builds a tailored HTML resume (and optionally a cover letter) from a master template and a verified career history.

## Workflow

1. **Receive the job description** from the user.
2. **Read both reference files** (mandatory, every time):
   - `references/professional-experience.md`: the single source of truth for career history
   - `references/content-guide.md`: bullet formulas, tone, and length rules
3. **Classify the role** (primary target, secondary target, or skip) using the criteria in the `job-search-coach` agent.
4. **Copy `assets/MASTER_RESUME_TEMPLATE.html`.** Never rebuild the HTML or CSS from scratch.
5. **Tailor the content** to the job description (see Tailoring below).
6. **Run the length check** before saving (see Length Targets).
7. **Save** to `generated-resumes/[[First-Last]]_[RoleName]_[CompanyName].html`.
8. **If a cover letter was requested:** read `assets/COVER_LETTER_TEMPLATE.html`, write it, and save to `generated-resumes/[[First-Last]]_Cover_Letter_[CompanyName].html`.
9. **Output for review:** remind the user to check accuracy and give the print steps.

## Always Start from the Master Template

The master template contains print-safe CSS. Copy it and change content only.

```css
/* NEVER ADD THIS */
.section { page-break-before: always; }
.page-break { page-break-after: always; }
```

```css
/* ALREADY IN THE TEMPLATE. KEEP IT */
.job { page-break-inside: avoid; }
```

Forced page breaks cause gaps when printing. Let content flow naturally.

## Tailoring

- **Summary:** rewrite to mirror the posting's priorities, using only facts from `professional-experience.md`.
- **Skills:** reorder so the ones the posting asks for come first. Never add a skill that isn't in the reference file.
- **Bullets:** choose the bullets from `professional-experience.md` that best match the posting, put the strongest first, and lightly rephrase for flow and keywords.
- **Keywords:** use the posting's own words where they honestly describe the work.

## Never Change (copy exactly from professional-experience.md)

- Job titles
- Company names
- Dates
- Education

## Never Do

- Invent or inflate accomplishments, metrics, or responsibilities.
- Merge or rename roles, or drop a role entirely.
- Add forced page breaks.

## Length Targets

- **Two pages maximum** when printed.
- **Current and recent roles:** 4 to 5 bullets.
- **Older roles:** 1 to 2 bullets.
- **One bullet = one to one-and-a-half rendered lines.** Cut trailing clauses first.
- **Summary:** 3 sentences maximum.

## Cover Letter

Only write one when the user asks for it.

- **Structure:** 3 short paragraphs plus a one-line close. Paragraph 1: why this company and role. Paragraph 2: the one or two most relevant things you've done, with outcomes. Paragraph 3: what you'd bring and what you want next.
- **Voice:** specific, plain, and confident. No throat-clearing ("I am writing to apply for...") and no repeating the resume.
- **Salutation:** use the hiring manager's name if the posting gives it; otherwise "Hello [Company] team,".
- **Facts:** same rule as the resume. Nothing that isn't in `professional-experience.md`.

## Quick Checklist

- [ ] Read both reference files
- [ ] Started from the master template
- [ ] Titles, companies, and dates match the reference exactly
- [ ] No invented accomplishments or metrics
- [ ] No forced page breaks
- [ ] Within the length targets
- [ ] Saved to `generated-resumes/` with the right file name
- [ ] Reminded the user to review for accuracy and print with background graphics ON
