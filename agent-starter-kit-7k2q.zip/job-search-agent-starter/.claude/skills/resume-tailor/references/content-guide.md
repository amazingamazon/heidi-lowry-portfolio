# Resume Content Guide

## Template Philosophy: "Let It Flow"

- Content flows like a normal document.
- The browser decides where pages break.
- Individual items (a job, a project) stay together on one page.
- No fighting with CSS. Clean, reliable printing.

Gaps in printed resumes come from forcing page breaks. Never force them.

## Bullet Writing Formula

**Pattern:** `[What changed or was achieved]. [How you did it, why it mattered, or the scale]`

The opening phrase is the outcome. A hiring manager reads only that first phrase at first glance, so it has to stand alone as a credibility signal.

**Good:**
- **Cut onboarding time from six weeks to three** by rebuilding the first-month plan with each team lead
- **Doubled the team from 4 to 8** and built the hiring and review process that kept quality steady as it grew
- **Launched the company's first self-serve checkout**, lifting trial-to-paid conversion by 14%

**Not this:**
- "Managed a team of 8 people" (a task, not an outcome)
- "Responsible for the checkout experience" (a duty, not a result)

If a real number exists, use it. If it doesn't, describe the concrete change instead. Never invent a metric.

## Tone

[[PICK ONE AND DELETE THE OTHER OR WRITE YOUR OWN]]

- **Confident and direct:** bold verbs (led, built, launched, cut, doubled), specific outcomes, short sentences.
- **Measured and collaborative:** verbs like partnered, aligned, improved, delivered; emphasis on teamwork and process.

## Summary Rules

- 3 sentences maximum.
- Sentence 1: your point of view. Sentence 2: what you do now, with specifics. Sentence 3: what you're known for.
- Cut any sentence that doesn't add new information.

## Text Style

- Write like the reader has 8 seconds. Every phrase has to earn its place.
- Prefer short declarative sentences over long compound ones.
- Cut: "while simultaneously", "in order to", "ensuring that", "helping to", "focused on".
- Use a dash only when the part after it adds a consequence rather than restating the first part.

## Length

- Two pages maximum.
- Current and recent roles: 4 to 5 bullets. Older roles: 1 to 2.
- One bullet = one to one-and-a-half lines.

## Tailoring to a Posting

1. Read the posting. Underline the 5 things it cares about most.
2. Put the matching bullets first in each role.
3. Reorder the skills so the posting's skills come first.
4. Rewrite the summary to speak to those 5 things, using only facts from `professional-experience.md`.
5. Use the posting's own words where they honestly describe your work.
