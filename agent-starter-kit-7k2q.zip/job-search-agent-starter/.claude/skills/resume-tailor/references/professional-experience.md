# Professional Experience: Single Source of Truth

> **SETUP NOTE (delete when done):** This file is the only place your agent gets facts about you. It never invents anything that isn't here. The more complete and honest this file is, the better every resume will be. Paste in your old resume and ask Claude to turn it into this format, then add any bullets that are missing.

## Contact

```
Name: [[FULL NAME]]
Email: [[EMAIL]]
Phone: [[PHONE]]
LinkedIn: [[LINKEDIN URL]]
Portfolio or website: [[URL, IF ANY]]
Location: [[CITY, STATE]]
```

## Summary Ingredients

Raw material for the summary. The agent will rewrite it per role.

- **Point of view:** [[ONE SENTENCE. What do you believe about your work?]]
- **What you do now:** [[ONE OR TWO SPECIFIC SENTENCES]]
- **What you're known for:** [[ONE SENTENCE]]

## Core Skills

[[LIST YOUR SKILLS, GROUPED. Example: Leadership: hiring, coaching, org design. Craft: systems thinking, research, prototyping. Domain: fintech, healthcare, enterprise software.]]

## Experience

Copy the title, company, and dates exactly as they should appear on every resume. Add a role block for each job, most recent first.

### [[JOB TITLE]], [[COMPANY]]
**Dates:** [[START MONTH YEAR]] to [[END MONTH YEAR OR Present]]
**Location:** [[CITY, STATE OR Remote]]

Bullets (write more than you'll use; the agent picks the best ones per role). Put the outcome first, then how you did it:

- [[BULLET: outcome first, then context and scale]]
- [[BULLET]]
- [[BULLET]]
- [[BULLET]]
- [[BULLET]]

### [[JOB TITLE]], [[COMPANY]]
**Dates:** [[START]] to [[END]]
**Location:** [[LOCATION]]

- [[BULLET]]
- [[BULLET]]
- [[BULLET]]

### [[JOB TITLE]], [[COMPANY]]
**Dates:** [[START]] to [[END]]
**Location:** [[LOCATION]]

- [[BULLET]]

(Copy the block above for each additional role.)

## Education

- [[DEGREE]], [[SCHOOL]], [[YEAR]]

## Certifications, Awards, Speaking (optional)

- [[ITEM]]

## Things Never to Say

[[OPTIONAL. Claims you're not comfortable making, topics to avoid, or details to keep off every resume.]]
